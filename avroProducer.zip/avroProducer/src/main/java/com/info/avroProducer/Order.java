package com.info.avroProducer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@AllArgsConstructor
@Data
@Builder
public class Order {

   private String  orderId;
    private String customerId;
    private String supplierId;
    private int items;
    private String firstName;
    private String lastName;
    private float price;
    private float weight;

}
