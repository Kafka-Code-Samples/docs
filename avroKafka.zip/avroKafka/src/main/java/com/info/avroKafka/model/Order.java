package com.info.avroKafka.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Order {

    String orderId;
    String customerId;
    String supplierId;
    int items;
    String firstName;
    String lastName;
    float price;
    float weight;

}
