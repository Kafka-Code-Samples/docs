package com.info.avroKafka.controller;
/*
import com.info.avroKafka.model.User;
import com.info.avroKafka.producer.Sender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ControllerDemo {

    @Autowired
    private Sender sender;

    @PostMapping(value = "/test")
    public String postData(@RequestBody User user){

        sender.send(user);
        return "success";
    }
}*/
